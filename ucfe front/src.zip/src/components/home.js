import React, { Component } from 'react'
import '../css/home.css';
import Navbar from './navbar.js';

class home extends Component {
  render() {
    return (
      <div className='Home'>
        <Navbar/>
        home
      </div>
    )
  }
}

export default home
