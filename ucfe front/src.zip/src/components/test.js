import React, { Component } from 'react'
import '../css/test.css';
import Navbar from './navbar.js';

class test extends Component {
  render() {
    return (
      <div className='Test'>
        <Navbar/>
        Test
      </div>
    )
  }
}

export default test
